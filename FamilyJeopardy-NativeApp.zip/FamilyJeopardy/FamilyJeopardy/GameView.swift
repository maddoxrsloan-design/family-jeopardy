import SwiftUI
import Combine

private let navy = Color(red: 0.055, green: 0.105, blue: 0.30)
private let boardBlue = Color(red: 0.075, green: 0.17, blue: 0.58)
private let gold = Color(red: 1.0, green: 0.82, blue: 0.31)

struct GameView: View {
    @State private var game: SavedGame = {
        guard let data = UserDefaults.standard.data(forKey: "savedFamilyJeopardy"),
              let result = try? JSONDecoder().decode(SavedGame.self, from: data),
              result.teamNames.count == 3, result.scores.count == 3,
              result.finalWagers.count == 3 else { return SavedGame() }
        return result
    }()
    @State private var selectedClue: Clue?
    @State private var showFinal = false
    @State private var showResetConfirmation = false

    var body: some View {
        GeometryReader { geometry in
            ScrollView {
                VStack(spacing: 20) {
                    header
                    scoreboards
                    board(availableWidth: geometry.size.width - 32)
                    HStack {
                        Text("\(game.usedClues.count) of 25 clues played")
                            .foregroundStyle(.white.opacity(0.8))
                        Spacer()
                        Button("Final Jeopardy") { showFinal = true }
                            .buttonStyle(.borderedProminent)
                            .tint(gold)
                            .foregroundStyle(navy)
                    }
                    .font(.subheadline.weight(.semibold))
                    Button(role: .destructive) { showResetConfirmation = true } label: {
                        Label("Start a New Game", systemImage: "arrow.counterclockwise")
                    }
                    .padding(.top, 8)
                }
                .padding(16)
                .frame(maxWidth: 1100)
                .frame(maxWidth: .infinity)
            }
            .background(navy.ignoresSafeArea())
        }
        .onChange(of: game) { newValue in
            if let data = try? JSONEncoder().encode(newValue) {
                UserDefaults.standard.set(data, forKey: "savedFamilyJeopardy")
            }
        }
        .sheet(item: $selectedClue) { clue in
            ClueSheet(clue: clue, onCorrect: { team in
                game.scores[team] += clue.value
                game.usedClues.insert(clue.id)
                selectedClue = nil
            }, onIncorrect: { team in
                game.scores[team] -= clue.value
            }, onSkip: {
                game.usedClues.insert(clue.id)
                selectedClue = nil
            })
            .presentationDragIndicator(.visible)
        }
        .sheet(isPresented: $showFinal) {
            FinalJeopardyView(game: $game)
                .presentationDragIndicator(.visible)
        }
        .confirmationDialog("Start a new game?", isPresented: $showResetConfirmation) {
            Button("Reset all questions and scores", role: .destructive) { game = SavedGame() }
        } message: {
            Text("All three team scores and completed questions will be cleared.")
        }
    }

    private var header: some View {
        VStack(spacing: 5) {
            Text("🏆 FAMILY")
                .font(.title2.bold())
                .foregroundStyle(.white)
            Text("JEOPARDY!")
                .font(.system(size: 38, weight: .black, design: .rounded))
                .minimumScaleFactor(0.6)
                .foregroundStyle(gold)
            Text("3 TEAMS  •  5 CATEGORIES  •  25 CLUES")
                .font(.caption2.weight(.bold))
                .tracking(1)
                .foregroundStyle(.white.opacity(0.7))
        }
        .frame(maxWidth: .infinity)
        .padding(.vertical, 10)
    }

    private var scoreboards: some View {
        HStack(spacing: 8) {
            ForEach(0..<3, id: \.self) { index in
                VStack(spacing: 8) {
                    TextField("Team name", text: $game.teamNames[index])
                        .font(.subheadline.bold())
                        .multilineTextAlignment(.center)
                        .textInputAutocapitalization(.words)
                        .autocorrectionDisabled()
                    Text(game.scores[index].formatted(.currency(code: "USD").precision(.fractionLength(0))))
                        .font(.system(size: 19, weight: .heavy, design: .rounded))
                        .minimumScaleFactor(0.55)
                        .lineLimit(1)
                        .foregroundStyle(gold)
                }
                .padding(.vertical, 14)
                .padding(.horizontal, 5)
                .frame(maxWidth: .infinity)
                .background(boardBlue.opacity(0.75), in: RoundedRectangle(cornerRadius: 12))
                .overlay(RoundedRectangle(cornerRadius: 12).strokeBorder(.white.opacity(0.2)))
            }
        }
    }

    private func board(availableWidth: CGFloat) -> some View {
        // On narrow iPhones, the board scrolls sideways instead of shrinking clues to unreadable text.
        let width = max(availableWidth, 590)
        return ScrollView(.horizontal) {
            VStack(spacing: 5) {
                HStack(spacing: 5) {
                    ForEach(0..<5, id: \.self) { c in
                        Text(GameData.categories[c])
                            .font(.system(size: 13, weight: .black))
                            .minimumScaleFactor(0.7)
                            .multilineTextAlignment(.center)
                            .foregroundStyle(.white)
                            .frame(maxWidth: .infinity, minHeight: 54)
                            .background(boardBlue, in: RoundedRectangle(cornerRadius: 5))
                    }
                }
                ForEach(0..<5, id: \.self) { row in
                    HStack(spacing: 5) {
                        ForEach(0..<5, id: \.self) { category in
                            let clue = GameData.clues[category][row]
                            Button {
                                selectedClue = clue
                            } label: {
                                Text(game.usedClues.contains(clue.id) ? "—" : "$\(clue.value)")
                                    .font(.system(size: 24, weight: .black, design: .rounded))
                                    .foregroundStyle(game.usedClues.contains(clue.id) ? .white.opacity(0.3) : gold)
                                    .frame(maxWidth: .infinity, minHeight: 68)
                                    .background(game.usedClues.contains(clue.id) ? boardBlue.opacity(0.25) : boardBlue,
                                                in: RoundedRectangle(cornerRadius: 5))
                            }
                            .disabled(game.usedClues.contains(clue.id))
                            .accessibilityLabel("\(GameData.categories[category]), \(clue.value) points")
                        }
                    }
                }
            }
            .frame(width: width)
        }
        .scrollIndicators(.visible)
    }
}

private struct ClueSheet: View {
    let clue: Clue
    let onCorrect: (Int) -> Void
    let onIncorrect: (Int) -> Void
    let onSkip: () -> Void

    @State private var showAnswer = false
    @State private var remaining = 30
    @State private var timerRunning = false
    @State private var penalizedTeams: Set<Int> = []
    @Environment(\.dismiss) private var dismiss
    private let ticker = Timer.publish(every: 1, on: .main, in: .common).autoconnect()

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 22) {
                    Text("\(GameData.categories[clue.category])  •  $\(clue.value)")
                        .font(.headline)
                        .foregroundStyle(gold)
                    Text(showAnswer ? clue.answer : clue.prompt)
                        .font(.system(size: 27, weight: .bold, design: .rounded))
                        .multilineTextAlignment(.center)
                        .frame(maxWidth: .infinity, minHeight: 180)
                        .padding(18)
                        .background(boardBlue, in: RoundedRectangle(cornerRadius: 16))
                    HStack(spacing: 14) {
                        Image(systemName: "timer")
                        Text("\(remaining)s")
                            .font(.title2.monospacedDigit().bold())
                        Button(timerRunning ? "Pause" : "Start Timer") { timerRunning.toggle() }
                            .buttonStyle(.bordered)
                        Button { remaining = 30; timerRunning = false } label: {
                            Image(systemName: "arrow.clockwise")
                        }
                        .buttonStyle(.bordered)
                        .accessibilityLabel("Reset timer")
                    }
                    .foregroundStyle(remaining == 0 ? .red : .white)
                    if !showAnswer {
                        Button("Reveal Answer") { showAnswer = true; timerRunning = false }
                            .buttonStyle(.borderedProminent)
                            .tint(gold)
                            .foregroundStyle(navy)
                            .font(.headline)
                        Text("Players should answer in the form of a question.")
                            .font(.footnote)
                            .foregroundStyle(.white.opacity(0.7))
                    } else {
                        Text("Who answered correctly?")
                            .font(.headline)
                        ForEach(0..<3, id: \.self) { team in
                            HStack(spacing: 10) {
                                Button("✓ Team \(team + 1): +$\(clue.value)") { onCorrect(team) }
                                    .buttonStyle(.borderedProminent)
                                    .tint(.green)
                                    .disabled(penalizedTeams.contains(team))
                                Button("✗ −$\(clue.value)") {
                                    penalizedTeams.insert(team)
                                    onIncorrect(team)
                                }
                                .buttonStyle(.bordered)
                                .tint(.red)
                                .disabled(penalizedTeams.contains(team))
                            }
                            .frame(maxWidth: .infinity)
                        }
                        Text("A wrong answer loses points. Another team can still answer.")
                            .font(.footnote)
                            .foregroundStyle(.white.opacity(0.7))
                    }
                    Button("Skip / Close Clue") { onSkip() }
                        .buttonStyle(.bordered)
                        .tint(.white)
                }
                .padding(20)
                .frame(maxWidth: 650)
                .frame(maxWidth: .infinity)
            }
            .background(navy.ignoresSafeArea())
            .navigationTitle("Jeopardy Clue")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button("Back") { dismiss() }
                }
            }
            .onReceive(ticker) { _ in
                if timerRunning && remaining > 0 { remaining -= 1 }
                if remaining == 0 { timerRunning = false }
            }
        }
        .preferredColorScheme(.dark)
    }
}

private struct FinalJeopardyView: View {
    @Binding var game: SavedGame
    @State private var reveal = false
    @State private var wagerStrings = ["0", "0", "0"]
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(spacing: 22) {
                    Text("🏆 FINAL JEOPARDY")
                        .font(.largeTitle.bold())
                        .foregroundStyle(gold)
                    Text("CATEGORY: SPACE EXPLORATION")
                        .font(.headline)
                        .foregroundStyle(.white.opacity(0.7))
                    Text(reveal ? "Who is Neil Armstrong?" : "In 1969, this astronaut became the first human to walk on the Moon.")
                        .font(.title.bold())
                        .multilineTextAlignment(.center)
                        .frame(maxWidth: .infinity, minHeight: 150)
                        .padding(16)
                        .background(boardBlue, in: RoundedRectangle(cornerRadius: 12))
                    Button(reveal ? "Hide Answer" : "Reveal Answer") { reveal.toggle() }
                        .buttonStyle(.borderedProminent)
                        .tint(gold)
                        .foregroundStyle(navy)
                    Text("Set wagers, then mark each team's answer. Maximum wager is the team's positive score. A team with no positive score may wager $0.")
                        .font(.footnote)
                        .foregroundStyle(.white.opacity(0.75))
                    ForEach(0..<3, id: \.self) { team in
                        VStack(alignment: .leading, spacing: 10) {
                            Text(game.teamNames[team].isEmpty ? "Team \(team + 1)" : game.teamNames[team])
                                .font(.headline)
                            HStack {
                                Text("Wager: $")
                                TextField("0", text: $wagerStrings[team])
                                    .keyboardType(.numberPad)
                                    .textFieldStyle(.roundedBorder)
                                    .frame(width: 110)
                                Spacer()
                                Text("Score: \(game.scores[team])")
                                    .font(.subheadline)
                            }
                            if game.finalResolved.contains(team) {
                                Label("Scored", systemImage: "checkmark.circle.fill")
                                    .foregroundStyle(.green)
                            } else {
                                HStack {
                                    Button("Correct +") { settle(team: team, correct: true) }
                                        .buttonStyle(.borderedProminent)
                                        .tint(.green)
                                    Button("Incorrect −") { settle(team: team, correct: false) }
                                        .buttonStyle(.bordered)
                                        .tint(.red)
                                }
                                .disabled(!validWager(team))
                            }
                        }
                        .padding(14)
                        .background(boardBlue.opacity(0.6), in: RoundedRectangle(cornerRadius: 12))
                    }
                    if game.finalResolved.count == 3 {
                        let winnerScore = game.scores.max() ?? 0
                        let winners = game.teamNames.indices.filter { game.scores[$0] == winnerScore }
                            .map { game.teamNames[$0] }.joined(separator: " & ")
                        Text("🎉 \(winners) \(game.scores.filter { $0 == winnerScore }.count > 1 ? "tie for the win!" : "wins!")")
                            .font(.title2.bold())
                            .multilineTextAlignment(.center)
                            .foregroundStyle(gold)
                    }
                }
                .padding(18)
                .frame(maxWidth: 650)
                .frame(maxWidth: .infinity)
            }
            .background(navy.ignoresSafeArea())
            .navigationTitle("Final Round")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar { ToolbarItem(placement: .topBarTrailing) { Button("Done") { dismiss() } } }
        }
        .preferredColorScheme(.dark)
    }

    private func validWager(_ team: Int) -> Bool {
        guard let wager = Int(wagerStrings[team]) else { return false }
        return wager >= 0 && wager <= max(0, game.scores[team])
    }

    private func settle(team: Int, correct: Bool) {
        guard !game.finalResolved.contains(team), validWager(team),
              let wager = Int(wagerStrings[team]) else { return }
        game.scores[team] += correct ? wager : -wager
        game.finalWagers[team] = wager
        game.finalResolved.insert(team)
    }
}
