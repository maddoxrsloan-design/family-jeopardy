import Foundation

struct Clue: Identifiable, Hashable {
    let category: Int
    let row: Int
    let prompt: String
    let answer: String

    var id: String { "\(category)-\(row)" }
    var value: Int { (row + 1) * 100 }
}

enum GameData {
    static let categories = ["🚀 SPACE", "🏛️ HISTORY", "🏒 SPORTS", "🧪 SCIENCE", "🐛 CATERPILLARS"]

    private static let questions: [[(String, String)]] = [
        [
            ("This planet is known as the Red Planet.", "What is Mars?"),
            ("This is the largest planet in our solar system.", "What is Jupiter?"),
            ("This force keeps planets in orbit around the Sun.", "What is gravity?"),
            ("This is the name of the galaxy containing our solar system.", "What is the Milky Way?"),
            ("This planet has the hottest average surface temperature in our solar system.", "What is Venus?")
        ],
        [
            ("This famous passenger ship sank in 1912.", "What is the Titanic?"),
            ("This ancient civilization built the pyramids at Giza.", "Who were the ancient Egyptians?"),
            ("This wall divided Berlin until 1989.", "What is the Berlin Wall?"),
            ("This Canadian became the first woman in space in 1992.", "Who is Roberta Bondar?"),
            ("This year marked the end of World War II.", "What is 1945?")
        ],
        [
            ("This sport is played using sticks and a puck on ice.", "What is ice hockey?"),
            ("This NBA basketball star is nicknamed King James.", "Who is LeBron James?"),
            ("This country won men's hockey gold at the 2010 Vancouver Olympics.", "What is Canada?"),
            ("This many players, including the goalie, are normally on the ice for one hockey team.", "What is six?"),
            ("This NHL legend scored 2,857 regular-season career points.", "Who is Wayne Gretzky?")
        ],
        [
            ("This is the chemical formula for water.", "What is H₂O?"),
            ("This gas is essential for human breathing.", "What is oxygen?"),
            ("This organ pumps blood throughout the human body.", "What is the heart?"),
            ("This process allows plants to turn sunlight into chemical energy.", "What is photosynthesis?"),
            ("This is the chemical symbol for gold.", "What is Au?")
        ],
        [
            ("Caterpillars eventually become these two kinds of insects.", "What are butterflies and moths?"),
            ("Many caterpillars eat these green parts of plants.", "What are leaves?"),
            ("This is how many true legs a caterpillar has.", "What is six?"),
            ("Many moth caterpillars spin cocoons using this material.", "What is silk?"),
            ("These fleshy, leg-like structures help caterpillars grip branches, but aren't true legs.", "What are prolegs?")
        ]
    ]

    static let clues: [[Clue]] = questions.enumerated().map { categoryIndex, group in
        group.enumerated().map { rowIndex, pair in
            Clue(category: categoryIndex, row: rowIndex, prompt: pair.0, answer: pair.1)
        }
    }
}

struct SavedGame: Codable, Equatable {
    var teamNames = ["Team 1", "Team 2", "Team 3"]
    var scores = [0, 0, 0]
    var usedClues: Set<String> = []
    var finalWagers = [0, 0, 0]
    var finalResolved: Set<Int> = []
}
