# Family Jeopardy — native app for iPhone, iPad, and Mac

This is an **Xcode SwiftUI project**, not a website or an HTML file.

## Open and play on a Mac

1. Download and unzip the project.
2. Install **Xcode** from the Mac App Store if you don't have it.
3. Open `FamilyJeopardy.xcodeproj` (inside the `FamilyJeopardy` folder).
4. At the top of Xcode, select the **FamilyJeopardy-Mac** scheme and **My Mac**.
5. Press **▶ Run**. It opens as a separate native Mac application.

## Open and play on an iPhone or iPad

1. Plug your iPhone or iPad into your Mac (or pair it with Xcode wirelessly).
2. Open the same project, and select **FamilyJeopardy-iOS** at the top.
3. Choose your iPhone/iPad from the Run destination list.
4. Under the iOS target's **Signing & Capabilities**, choose your Apple development team (a free Apple ID can be used for personal development, subject to Apple's limitations).
5. If Xcode asks, enable Developer Mode on your device and follow the on-screen trust steps.
6. Press **▶ Run**. The app gets installed on your device.

You can also select an iPhone/iPad simulator to try the game before installing it on a physical device.

## What's included

- 5 categories: Space, History, Sports, Science, Caterpillars
- 25 clues from $100 to $500
- 3 renameable teams, live scorekeeping, answer reveals, and correct/incorrect scoring
- Final Jeopardy, with wagers and a winner announcement
- Game progress saved locally on each device; New Game resets it

## Notes

- Requires macOS 13+ / iOS 16+ to run and a compatible version of Xcode to build.
- Scores saved on one device **do not sync** to another.
- The app is not submitted to the App Store. App Store publishing and distribution require additional Apple Developer steps.
- This project was created without access to Xcode, so it has **not** been compiled or device-tested here.
